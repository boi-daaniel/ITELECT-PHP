<?php
$hostname = "localhost";
$username = "root";
$password = "123";
$database = "employee_management";

$conn = new mysqli($hostname, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection Failed" . $conn->connect_error);
}

?>