<?php
include 'config/db.php';

$id = $name = $email = $phone_number = $position = $department = $salary = "";
$errorMessage = $successMessage = "";

// GET: Fetch employee data
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (!isset($_GET["id"])) {
        header("location: /employee_management/index.php");
        exit;
    }
    $id = $_GET["id"];

    $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (!$row) {
        header("Location: /employee_management/index.php");
        exit;
    }

    //Fill form values
    $name = $row["name"];
    $email = $row["email"];
    $phone_number = $row["phone_number"];
    $position = $row["position"];
    $department = $row["department"];
    $salary = $row["salary"];
} else {
    // POST: Update employee
    $id = $_POST["id"];
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone_number = $_POST["phone_number"];
    $position = $_POST["position"];
    $department = $_POST["department"];
    $salary = $_POST["salary"];

    do {
        //Validation
        if (
            empty($id) || empty($name) || empty($email) || empty($phone_number) ||
            empty($position) || empty($department) || empty($salary)
        ) {
            $errorMessage = "All fields are required!";
            break;
        }

        //Update query
        $sql = "UPDATE employees SET name=?, email=?, phone_number=?, position=?, department=?, salary=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            $errorMessage = "Database error: " . $conn->error;
            break;
        }

        $stmt->bind_param("ssssssi", $name, $email, $phone_number, $position, $department, $salary, $id);
        $stmt->execute();

        $successMessage = "Employee updated successfully!";
        header("Location: /employee_management/index.php");
        exit;
    } while (true);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee</title>
    <link href="./output.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h2>Edit Employee</h2>
        <!-- Error Message -->
        <?php
        if (!empty($errorMessage)) {
            echo "<div class='alert alert-danger'>$errorMessage</div>";
        }
        ?>
        <form action="" method="post">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <!-- Name -->
            <div class="row">
                <label>Name</label>
                <div>
                    <input type="text" class="form-control" name="name" value="<?php echo $name; ?>">
                </div>
            </div>
            <!-- Email -->
            <div class="row">
                <label>Email</label>
                <div>
                    <input type="text" class="form-control" name="email" value="<?php echo $email; ?>">
                </div>
            </div>
            <!-- Phone Number -->
            <div class="row">
                <label>Phone Number</label>
                <div>
                    <input type="text" class="form-control" name="phone_number" value="<?php echo $phone_number; ?>">
                </div>
            </div>
            <!-- Position -->
            <div class="row">
                <label>Position</label>
                <div>
                    <input type="text" class="form-control" name="position" value="<?php echo $position; ?>">
                </div>
            </div>
            <!-- Department -->
            <div class="row">
                <label>Department</label>
                <div>
                    <input type="text" class="form-control" name="department" value="<?php echo $department; ?>">
                </div>
            </div>
            <!-- Salary -->
            <div class="row">
                <label>Salary</label>
                <div>
                    <input type="text" class="form-control" name="salary" value="<?php echo $salary; ?>">
                </div>
            </div>
            <!-- Success Message -->
            <?php
            if (!empty($successMessage)) {
                echo "<div class='alert alert-success'>$successMessage</div>";
            }
            ?>
            <!-- Buttons -->
            <br>

            <div class="row">
                <div>
                    <button type="submit">Submit</button>
                </div>
                <div>
                    <a href="/employee_management/index.php" role="button">Cancel</a>
                </div>
            </div>

        </form>
    </div>
</body>

</html>