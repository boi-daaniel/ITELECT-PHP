<?php
include 'config/db.php';
$name = $email = $phone_number = $position = $department = $salary = "";
$successMessage = $errorMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone_number = $_POST["phone_number"];
    $position = $_POST["position"];
    $department = $_POST["department"];
    $salary = $_POST["salary"];


    do {
        //Validation
        if (
            empty($name) || empty($email) || empty($phone_number) ||
            empty($position) || empty($department) || empty($salary)
        ) {
            $errorMessage = "All fields are required.";
            break;
        }

        // Insert query
        $sql = "INSERT INTO employees (name, email, phone_number, position, department, salary) 
                VALUES (?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            $errorMessage = "Prepare failed: " . $conn->error;
            break;
        }

        $stmt->bind_param("ssssss", $name, $email, $phone_number, $position, $department, $salary);

        if (!$stmt->execute()) {
            $errorMessage = "Execute failed: " . $stmt->error;
            break;
        }

        // Success
        $successMessage = "Employee Added Successfully";
        header("Location: /employee_management/index.php");
        exit;
    } while (false);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Employee</title>
    <link href="./output.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h2>Add Employee</h2>
        <!-- Error Message -->
        <?php
        if (!empty($errorMessage)) {
            echo "<div class='alert alert-danger'>$errorMessage</div>";
        }
        ?>
        <form action="" method="post">
            <!-- Name -->
            <div class="row">
                <label>Name</label>
                <div>
                    <input type="text" class="form-control" name="name" value="<?php echo $name; ?>">
                </div>
            </div>
            <!-- Email -->
            <div class="row">
                <label>Email</label>
                <div>
                    <input type="text" class="form-control" name="email" value="<?php echo $email; ?>">
                </div>
            </div>
            <!-- Phone Number -->
            <div class="row">
                <label>Phone Number</label>
                <div>
                    <input type="text" class="form-control" name="phone_number" value="<?php echo $phone_number; ?>">
                </div>
            </div>
            <!-- Position -->
            <div class="row">
                <label>Position</label>
                <div>
                    <input type="text" class="form-control" name="position" value="<?php echo $position; ?>">
                </div>
            </div>
            <!-- Department -->
            <div class="row">
                <label>Department</label>
                <div>
                    <input type="text" class="form-control" name="department" value="<?php echo $department; ?>">
                </div>
            </div>
            <!-- Salary -->
            <div class="row">
                <label>Salary</label>
                <div>
                    <input type="text" class="form-control" name="salary" value="<?php echo $salary; ?>">
                </div>
            </div>
            <!-- Success Message -->
            <?php
            if (!empty($successMessage)) {
                echo "<div class='alert alert-success'>$successMessage</div>";
            }
            ?>
            <!-- Buttons -->
            <br>

            <div class="row">
                <div>
                    <button type="submit">Submit</button>
                </div>
                <div>
                    <a href="/employee_management/index.php" role="button">Cancel</a>
                </div>
            </div>

        </form>
    </div>
</body>

</html>