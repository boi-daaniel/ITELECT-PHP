<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Employee Management</title>
    <link href="./src/output.css" rel="stylesheet" />
</head>

<body class="min-h-screen p-6">
    <div class="w-full max-w-7xl mx-auto bg-white text-black rounded-md shadow-lg overflow-hidden">
        <!-- Header -->
        <div class="flex items-center justify-between bg-gray-900 px-6 py-4">
            <h2 class="text-xl font-bold text-white">Employee Management</h2>
            <a href="create.php"
                class="bg-white font-semibold text-sm px-4 py-2 rounded-full hover:bg-gray-200 transition">
                Add Employee
            </a>
        </div>

        <!-- Table -->
        <div class="overflow-x-auto">
            <table class="w-full text-center text-sm">
                <thead class="bg-white uppercase font-bold border-b border-black">
                    <tr>
                        <th class="px-4 py-3">ID</th>
                        <th class="px-4 py-3">Name</th>
                        <th class="px-4 py-3">Email</th>
                        <th class="px-4 py-3">Phone Number</th>
                        <th class="px-4 py-3">Position</th>
                        <th class="px-4 py-3">Department</th>
                        <th class="px-4 py-3">Salary</th>
                        <th class="px-4 py-3">Date Created</th>
                        <th class="px-4 py-3">Action</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-300 text-black">
                    <?php
                    include 'config/db.php';

                    if ($conn->connect_error) {
                        die("Connection Failed: " . $conn->connect_error);
                    }

                    $sql = "SELECT * FROM employees";
                    $result = $conn->query($sql);

                    if (!$result) {
                        die("Invalid query: " . $conn->connect_error);
                    }

                    while ($row = $result->fetch_assoc()) {
                        echo "
                            <tr class='hover:bg-gray-50'>
                                <td class='px-4 py-2'>{$row['id']}</td>
                                <td class='px-4 py-2'>{$row['name']}</td>
                                <td class='px-4 py-2'>{$row['email']}</td>
                                <td class='px-4 py-2'>{$row['phone_number']}</td>
                                <td class='px-4 py-2'>{$row['position']}</td>
                                <td class='px-4 py-2'>{$row['department']}</td>
                                <td class='px-4 py-2'>{$row['salary']}</td>
                                <td class='px-4 py-2'>{$row['created_at']}</td>
                                <td class='px-4 py-2 space-x-2'>
                                    <a href='edit.php?id={$row['id']}' class='inline-block bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-full text-xs font-semibold'>Edit</a>
                                    <a href='delete.php?id={$row['id']}' onclick='return confirm(\"Delete this employee?\");' class='inline-block bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded-full text-xs font-semibold'>Delete</a>
                                </td>
                            </tr>
                        ";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>
