<?php
include 'config/db.php';

if (isset($_GET["id"])) {
    $id = $_GET["id"];

    $sql = "DELETE FROM employees where id = $id";
    $conn->query($sql);
}

header("location: /employee_management/index.php");
exit;
?>