<?php
require_once "pdo\pdo.php";
if ( isset($_POST['email']) && isset($_POST['password'])  ) {
    $e = $_POST['email'];
    $p = $_POST['password'];
    $sql = "SELECT name FROM users
         WHERE email = '$e'
         AND password = '$p'";
    $stmt = $pdo->query($sql);
}
<?php
<html>
<form>
<p><strong>Please Login</strong></p>
<label for="email">Email:</label>
<input type="email" id="email" name="email" value="cleve@umich.edu" class="highlight"><br><br>

<label for="password">Password:</label>
<input type="password" id="password" name="password" value="wrong"><br><br>

<button type="submit">Login</button>
<a href="#">Refresh</a>
</form> 