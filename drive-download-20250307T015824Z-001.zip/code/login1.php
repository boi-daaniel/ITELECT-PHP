<?php
require_once "../pdo/pdo.php";

if (isset($_POST['email']) && isset($_POST['password'])) {
    $e = $_POST['email'];
    $p = $_POST['password'];

    $sql = "SELECT name FROM users 
            WHERE email = '$e' AND password = '$p'";
    echo "<p>Handling POST data...</p>";
    echo "<p>SQL Query: $sql</p>";

    $stmt = $pdo->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        echo "<p>Login success.";
    } else {
        echo "<p><strong>Login incorrect.</strong></p>";
    }
}
?>

<form method="POST">
    <p>Email: <input type="text" name="email"></p>
    <p>Password: <input type="text" name="password"></p> <!-- Intentionally text to test SQL injection -->
    <p><input type="submit" value="Login"></p>
</form>
