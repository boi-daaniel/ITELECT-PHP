<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Management</title>
    <link href="./output.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h2>Employee Management</h2>
        <a href="create.php" role="button">Add Employee</a>
        <table class="text-center">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Position</th>
                    <th>Department</th>
                    <th>Salary</th>
                    <th>Dated Created</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'config/db.php';

                if ($conn->connect_error) {
                    die("Connection Failed" . $conn->connect_error);
                }

                $sql = "SELECT * FROM employees";
                $result = $conn->query($sql);
                if (!$result) {
                    die("Invalid query" . $conn->connect_error);
                }

                while ($row = $result->fetch_assoc()) {
                    echo "
                        <tr>
                            <td>{$row['id']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['email']}</td>
                            <td>{$row['phone_number']}</td>
                            <td>{$row['position']}</td>
                            <td>{$row['department']}</td>
                            <td>{$row['salary']}</td>
                            <td>{$row['created_at']}</td>
                            <td>
                                <a href='/employee_management/edit.php?id={$row['id']}'>Edit</a>
                                <a href='/employee_management/delete.php?id={$row['id']}'>Delete</a>
                            </td>
                        </tr>
                    ";
                }
                ?>
                <a href=""></a>
            </tbody>
        </table>
    </div>
</body>

</html>