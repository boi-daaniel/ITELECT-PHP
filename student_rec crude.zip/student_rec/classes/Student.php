<?php
class Student {
    public $firstname;
    public $lastname;
    public $course;
    public $address;
    public $dob;

    public function __construct($firstname, $lastname, $course, $address, $dob) {
        $this->firstname = $firstname;
        $this->lastname = $lastname;
        $this->course = $course;
        $this->address = $address;
        $this->dob = $dob;
    }

    // Serialize only necessary properties
    public function serializeData() {
        // Serialize only basic student information
        return serialize([
            'firstname' => $this->firstname,
            'lastname' => $this->lastname,
            'course' => $this->course,
            'address' => $this->address,
            'dob' => $this->dob
        ]);
    }
}
?>
