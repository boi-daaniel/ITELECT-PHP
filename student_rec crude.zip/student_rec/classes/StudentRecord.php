<?php
require_once __DIR__ . '/../config/pdo.php';
require_once 'Student.php';

class StudentRecord extends Student {
    private $conn;

    public function __construct($firstname, $lastname, $course, $address, $dob) {
        parent::__construct($firstname, $lastname, $course, $address, $dob);

        // Database connection
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    // Save student record to database
    public function save() {
        // Serialize only student data, not the PDO connection
        $serializedData = $this->serializeData();

        $query = "INSERT INTO students (firstname, lastname, course, address, dob, serialized_data) 
                  VALUES (:firstname, :lastname, :course, :address, :dob, :serialized_data)";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':firstname', $this->firstname);
        $stmt->bindParam(':lastname', $this->lastname);
        $stmt->bindParam(':course', $this->course);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':dob', $this->dob);
        $stmt->bindParam(':serialized_data', $serializedData);

        if ($stmt->execute()) {
            echo "Student record saved successfully.";
        } else {
            echo "Error saving student record.";
        }
    }

    // Exclude PDO from serialization
    public function __sleep() {
        return ['firstname', 'lastname', 'course', 'address', 'dob'];
    }

    public function __wakeup() {
        // Reconnect to the database after unserializing
        $database = new Database();
        $this->conn = $database->getConnection();
    }
}
?>
