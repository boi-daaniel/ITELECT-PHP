<?php
require_once 'classes/StudentRecord.php';
require_once 'config/pdo.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = htmlspecialchars($_POST['firstname']);
    $lastname = htmlspecialchars($_POST['lastname']);
    $course = htmlspecialchars($_POST['course']);
    $address = htmlspecialchars($_POST['address']);
    $dob = $_POST['dob'];

    $studentRecord = new StudentRecord($firstname, $lastname, $course, $address, $dob);
    $studentRecord->save();

    header("Location: index.php");
    exit();
}

$students = [];
try {
    $database = new Database();
    $conn = $database->getConnection();
    $stmt = $conn->query("SELECT * FROM students");
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<div class='bg-red-100 text-red-700 p-3 rounded mb-4'>Error fetching students: " . $e->getMessage() . "</div>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Information</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 p-8">
    <center>
    <div class="max-w-3xl mx-auto bg-white p-6 rounded-lg shadow-lg">
        <h2 class="text-2xl font-bold mb-4">Student Information Form</h2>

        <div class="max-w-4xl mx-auto mt-8 bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-4">Student Records</h2>
            <div class="overflow-x-auto">
                <table class="w-full border border-gray-300 rounded-lg">
                    <thead>
                        <tr class="bg-gray-200 text-gray-700">
                            <th class="border px-4 py-2">ID</th>
                            <th class="border px-4 py-2">First Name</th>
                            <th class="border px-4 py-2">Last Name</th> 
                            <th class="border px-4 py-2">Course</th>
                            <th class="border px-4 py-2">Address</th>
                            <th class="border px-4 py-2">DOB</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $index => $student): ?>
                            <tr class="<?php echo $index % 2 == 0 ? 'bg-gray-100' : 'bg-white'; ?>">
                                <td class="border px-4 py-2"><?php echo htmlspecialchars($student['id']); ?></td>
                                <td class="border px-4 py-2"><?php echo htmlspecialchars($student['firstname']); ?></td>
                                <td class="border px-4 py-2"><?php echo htmlspecialchars($student['lastname']); ?></td>
                                <td class="border px-4 py-2"><?php echo htmlspecialchars($student['course']); ?></td>
                                <td class="border px-4 py-2"><?php echo htmlspecialchars($student['address']); ?></td>
                                <td class="border px-4 py-2"><?php echo htmlspecialchars($student['dob']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($students)): ?>
                            <tr>
                                <td colspan="6" class="border px-4 py-2 text-center text-gray-500">No student records found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <br>

        <form method="POST" action="index.php" class="space-y-4">
            <input type="text" name="firstname" placeholder="First Name" class="w-full p-2 border rounded" required>
            <input type="text" name="lastname" placeholder="Last Name" class="w-full p-2 border rounded" required>
            <input type="text" name="course" placeholder="Course" class="w-full p-2 border rounded" required>
            <input type="text" name="address" placeholder="Address" class="w-full p-2 border rounded" required>
            <input type="date" name="dob" class="w-full p-2 border rounded" required>
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Save
                Student</button>
        </form>
    </div>

    </center>
</body>

</html>