<?php
require_once 'classes/Student.php';
require_once 'config/pdo.php';

$student = new Student();

// Handle save (insert) action
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['delete_student']) && !isset($_POST['update_student'])) {
    $data = [
        "firstname" => $_POST['firstname'],
        "lastname" => $_POST['lastname'],
        "course" => $_POST['course'],
        "address" => $_POST['address'],
        "dob" => $_POST['dob'],
    ];
    $student->saveStudent($data);
    header("Location: index.php");
    exit();
}

// Handle delete action
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_student'])) {
    $id = $_POST['student_id'];
    $student->delete($id);
    header("Location: index.php");
    exit();
}

// Handle update action
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_student'])) {
    $id = $_POST['student_id'];
    $data = [
        "firstname" => $_POST['firstname'],
        "lastname" => $_POST['lastname'],
        "course" => $_POST['course'],
        "address" => $_POST['address'],
        "dob" => $_POST['dob'],
    ];
    // Re-serialize the data before updating
    $data['serialized_data'] = $student->serializeData($data);
    $student->update($id, $data);
    header("Location: index.php");
    exit();
}

// Fetch students
$students = $student->getAll();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Information</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Edit modal -->
    <script>
        function openEditModal(id, firstname, lastname, course, address, dob) {
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_firstname').value = firstname;
            document.getElementById('edit_lastname').value = lastname;
            document.getElementById('edit_course').value = course;
            document.getElementById('edit_address').value = address;
            document.getElementById('edit_dob').value = dob;
            document.getElementById('editModal').style.display = 'block';
        }
        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
    </script>
</head>

<body class="bg-gray-100 p-8">
    <!-- Flex container for the Student Table and Create Student Form -->
    <div class="flex space-x-5">
        <!-- Student Table with Scroll Bar -->
        <div class="flex-1 bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-4">Student Records</h2>
            <div class="overflow-y-auto" style="max-height: 400px;"> <!-- Added max-height and overflow -->
                <table class="w-full border border-gray-300 rounded-lg">
                    <thead>
                        <tr class="bg-gray-200 text-gray-700">
                            <th class="border px-4 py-2">ID</th>
                            <th class="border px-4 py-2">First Name</th>
                            <th class="border px-4 py-2">Last Name</th>
                            <th class="border px-4 py-2">Course</th>
                            <th class="border px-4 py-2">Address</th>
                            <th class="border px-4 py-2">DOB</th>
                            <th class="border px-4 py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $index => $student): ?>
                            <tr class="<?= $index % 2 == 0 ? 'bg-gray-100' : 'bg-white' ?>">
                                <td class="border px-4 py-2"><?= htmlspecialchars($student['id']) ?></td>
                                <td class="border px-4 py-2"><?= htmlspecialchars($student['firstname']) ?></td>
                                <td class="border px-4 py-2"><?= htmlspecialchars($student['lastname']) ?></td>
                                <td class="border px-4 py-2"><?= htmlspecialchars($student['course']) ?></td>
                                <td class="border px-4 py-2"><?= htmlspecialchars($student['address']) ?></td>
                                <td class="border px-4 py-2"><?= htmlspecialchars($student['dob']) ?></td>
                                <td class="border px-4 py-2 flex space-x-2">
                                    <button onclick="openEditModal(
                                '<?= $student['id'] ?>',
                                '<?= htmlspecialchars($student['firstname'], ENT_QUOTES) ?>',
                                '<?= htmlspecialchars($student['lastname'], ENT_QUOTES) ?>',
                                '<?= htmlspecialchars($student['course'], ENT_QUOTES) ?>',
                                '<?= htmlspecialchars($student['address'], ENT_QUOTES) ?>',
                                '<?= $student['dob'] ?>'
                            )" class="bg-yellow-500 text-white px-2 py-1 rounded">Edit</button>

                                    <form method="POST" action="index.php" onsubmit="return confirm('Are you sure?');">
                                        <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
                                        <button type="submit" name="delete_student"
                                            class="bg-red-500 text-white px-2 py-1 rounded">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($students)): ?>
                            <tr>
                                <td colspan="7" class="border px-4 py-2 text-center text-gray-500">No student records found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Create Student Form (Right side) -->
        <div class="flex-1 bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-4">Student Information Form</h2>

            <form method="POST" action="index.php" class="space-y-4">
                <input type="text" name="firstname" placeholder="First Name" class="w-full p-2 border rounded" required>
                <input type="text" name="lastname" placeholder="Last Name" class="w-full p-2 border rounded" required>
                <input type="text" name="course" placeholder="Course" class="w-full p-2 border rounded" required>
                <input type="text" name="address" placeholder="Address" class="w-full p-2 border rounded" required>
                <input type="date" name="dob" class="w-full p-2 border rounded" required>
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Save
                    Student</button>
            </form>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg">
            <h2 class="text-2xl font-bold mb-4">Edit Student</h2>
            <form method="POST" action="index.php">
                <input type="hidden" id="edit_id" name="student_id">
                <input type="text" id="edit_firstname" name="firstname" placeholder="First Name"
                    class="w-full p-2 border rounded" required>
                <input type="text" id="edit_lastname" name="lastname" placeholder="Last Name"
                    class="w-full p-2 border rounded" required>
                <input type="text" id="edit_course" name="course" placeholder="Course" class="w-full p-2 border rounded"
                    required>
                <input type="text" id="edit_address" name="address" placeholder="Address"
                    class="w-full p-2 border rounded" required>
                <input type="date" id="edit_dob" name="dob" class="w-full p-2 border rounded" required>
                <button type="submit" name="update_student"
                    class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Update</button>
            </form>
            <button onclick="closeEditModal()" class="mt-2 bg-gray-500 text-white px-4 py-2 rounded">Close</button>
        </div>
    </div>
</body>

</html>