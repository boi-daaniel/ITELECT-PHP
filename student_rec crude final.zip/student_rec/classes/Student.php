<?php
require_once __DIR__ . '/../model/model.php';

class Student extends Model
{
    public function __construct()
    {
        parent::__construct('students'); // Set the table name
    }

    // Save student record after validation & serialization
    public function saveStudent($data)
    {
        if ($this->validate($data)) {
            // Add serialized data before saving
            $data['serialized_data'] = $this->serializeData($data);
            return $this->save($data);  // Now serialized_data is explicitly included
        } else {
            echo "Validation failed.";
            return false;
        }
    }

    // Validate required fields
    private function validate($data)
    {
        return isset($data['firstname'], $data['lastname'], $data['course'], $data['address'], $data['dob']);
    }

    // Serialize only necessary fields
    public function serializeData($data)
    {
        return serialize([
            'firstname' => $data['firstname'],
            'lastname' => $data['lastname'],
            'course' => $data['course'],
            'address' => $data['address'],
            'dob' => $data['dob'],
        ]);
    }
}
?>