<?php
require_once __DIR__ . '/../config/pdo.php';

class Model
{
    protected $conn;
    protected $table;

    public function __construct($table)
    {
        $database = new Database();
        $this->conn = $database->getConnection();
        $this->table = $table;
    }

    // Save record
    public function save($data)
    {
        // Check if serialized_data is set, if not provide a default (e.g., empty string or serialized empty array)
        if (!isset($data['serialized_data'])) {
            $data['serialized_data'] = serialize([]); // or any default value
        }

        $columns = 'firstname, lastname, course, address, dob, serialized_data';
        $placeholders = ':firstname, :lastname, :course, :address, :dob, :serialized_data';

        $query = "INSERT INTO {$this->table} ($columns) VALUES ($placeholders)";
        $stmt = $this->conn->prepare($query);

        return $stmt->execute($data);
    }

    // Update record by ID
    public function update($id, $data)
    {
        $fields = "firstname = :firstname, lastname = :lastname, course = :course, address = :address, dob = :dob, serialized_data = :serialized_data";

        $query = "UPDATE {$this->table} SET $fields WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $data['id'] = $id;

        return $stmt->execute($data);
    }

    // Get ID
    public function get($id)
    {
        $query = "SELECT * FROM {$this->table} WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Delete record by ID
    public function delete($id)
    {
        $query = "DELETE FROM {$this->table} WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute(['id' => $id]);
    }

    // Get all records
    public function getAll()
    {
        $query = "SELECT * FROM {$this->table}";
        $stmt = $this->conn->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
